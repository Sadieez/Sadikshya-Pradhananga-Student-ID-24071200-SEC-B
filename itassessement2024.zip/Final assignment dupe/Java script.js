// Wait until the page has fully loaded
document.addEventListener('DOMContentLoaded', function() {

    // Highlight the current page link
    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll('.navigation a');
  
    links.forEach(link => {
      if (link.getAttribute('href') === currentPage) {
        link.style.backgroundColor = '#ddd';
        link.style.borderRadius = '5px';
      }
    });
  
    // Contact form message
    const form = document.querySelector('form');
    if (form) {
      form.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('name').value;
        alert("Thanks " + name + "! We got your message.");
        form.reset();
      });
    }
  
  });
  
  